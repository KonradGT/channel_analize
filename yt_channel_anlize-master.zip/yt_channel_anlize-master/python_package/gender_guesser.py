from gender_guesser.detector import Detector
import re
from concurrent.futures import ThreadPoolExecutor


def extract_first_name(username):
    # Remove non-alphabetical characters and split by common separators
    clean_name = re.sub(r'[^a-zA-Z]', ' ', username)
    name_parts = clean_name.split()
    return name_parts[0] if name_parts else None


def guess_gender_worker(username, detector):
    first_name = extract_first_name(username['name'])
    if first_name:
        gender = detector.get_gender(first_name)
    else:
        gender = "unknown"
    return {"username": username, "first_name": first_name, "gender": gender}


def gender_summary_generator(results):
    total_count = len(results)
    gender_counts = {"male": 0, "female": 0, "unknown": 0, "andy": 0, "other": 0}

    for result in results:
        if result['gender'] in ['male', 'mostly_male']:
            gender_counts['male'] += 1
        elif result['gender'] in ['female', 'mostly_female']:
            gender_counts['female'] += 1
        else:
            gender_counts[result['gender']] += 1

    male_female_count = gender_counts['male'] + gender_counts['female']

    if male_female_count == 0:
        return 0, 0
    else:
        male_percentage = gender_counts['male'] / male_female_count * 100
        female_percentage = gender_counts['female'] / male_female_count * 100
        return male_percentage, female_percentage



def guess_gender_parallel(comment_authors):
    detector = Detector(case_sensitive=False)
    with ThreadPoolExecutor(max_workers=20) as executor:
        results = list(executor.map(guess_gender_worker, comment_authors, [detector] * len(comment_authors)))
    return results

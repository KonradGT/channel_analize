from datetime import datetime, timedelta
import joblib


def find_between(s, first, last,):
    try:
        start = s.index(first) + len(first)
        end = s.index(last, start)
        return s[start:end]
    except ValueError:
        return ""


def avg(lst):
    return sum(lst) / len(lst)


def form_output(data_videos, videos_ads_list, videos_link_list, videos_views_list, videos_like_list,
                videos_comment_list, videos_published_list, videos_title_list, videos_desc_list, videos_duration_list,
                videos_kids_list, channel_details, first_ad_count, first_five_ad_count, overall_ad_count,
                male_percentage, female_percentage, creation_year_division, age_brackets, views_to_sub_ratio):

    last_30_days_views = 0
    last_30_days_video_count = 0
    current_date = datetime.utcnow()

    for video in data_videos['items']:

        try:
            videos_like_list.append(int(video['statistics']['likeCount']))
        except KeyError:
            videos_like_list.append(1)

        try:
            videos_comment_list.append(int(video['statistics']['commentCount']))
        except KeyError:
            videos_comment_list.append(1)

        published_date = video['snippet']['publishedAt']
        videos_published_list.append(published_date)
        published_datetime = datetime.fromisoformat(published_date[:-1])

        if (current_date - published_datetime).days <= 30:
            last_30_days_video_count += 1
            last_30_days_views += int(video['statistics']['viewCount'])

        videos_title_list.append(video['snippet']['title'])
        try:
            videos_desc_list.append(video['snippet']['description'][0:100])
        except:
            videos_desc_list.append(video['snippet']['description'])
        videos_duration_list.append(video['contentDetails']['duration'])
        videos_kids_list.append(video['status']['madeForKids'])

    video_frequency = last_30_days_video_count / 30

    # Access 'topicDetails' safely with a default empty dictionary if it's missing
    topic_details = channel_details['items'][0].get('topicDetails', {})

    # From 'topicDetails', safely get 'topicCategories' with a default empty list if it's missing
    categories = topic_details.get('topicCategories', [])

    output = {
        'id': channel_details['items'][0]['id'],
        'title': channel_details['items'][0]['brandingSettings']['channel']['title'],
        'avg_views': avg(videos_views_list),
        'min_views': min(videos_views_list),
        'max_views': max(videos_views_list),
        'avg_likes': avg(videos_like_list),
        'min_likes': min(videos_like_list),
        'max_likes': max(videos_like_list),
        'avg_comment_count': avg(videos_comment_list),
        'min_comment_count': min(videos_comment_list),
        'max_comment_count': max(videos_comment_list),
        'views_to_sub_ratio': views_to_sub_ratio,
        'last_video_ad': first_ad_count,
        'five_last_videos_ads_count': first_five_ad_count,
        'fifteen_last_videos_ads_count': overall_ad_count,
        'male_percentage': male_percentage,
        'female_percentage': female_percentage,
        'categories': categories,
        'country': channel_details['items'][0]['brandingSettings']['channel'].get('country', ''),
        'description': channel_details['items'][0]['brandingSettings']['channel'].get('description', ''),
        'subscriber_count': channel_details['items'][0]['statistics']['subscriberCount'],
        'video_count': channel_details['items'][0]['statistics']['videoCount'],
        'view_count': channel_details['items'][0]['statistics']['viewCount'],
        'published_at': data_videos['items'][0]['snippet']['publishedAt'],
        'videos_views_list': videos_views_list,
        'videos_like_list': videos_like_list,
        'videos_comment_list': videos_comment_list,
        'videos_published_list': videos_published_list,
        'videos_title_list': videos_title_list,
        'videos_desc_list': videos_desc_list,
        'videos_duration_list': videos_duration_list,
        'videos_kids_list': videos_kids_list,
        'videos_ads_list': videos_ads_list,
        'videos_link_list': videos_link_list,
        'video_count_last_30_days': last_30_days_video_count,
        'views_last_30_days': last_30_days_views,
        'video_frequency': video_frequency,
        'creation_year_division': creation_year_division,
        'age_brackets': age_brackets
    }

    return output


def last_videos_id(video_id_list):
    now = datetime.utcnow()
    lower_bound = now - timedelta(days=120)
    upper_bound = now - timedelta(days=2)

    return [video for video in video_id_list if lower_bound.isoformat() + 'Z' < video['contentDetails'][
        'videoPublishedAt'] < upper_bound.isoformat() + 'Z'][:15]


def average_time_between_dates(dates):
    # Convert strings to datetime objects
    dates = [datetime.fromisoformat(date) for date in dates]

    # Compute time differences in seconds
    deltas = [(dates[i + 1] - dates[i]).total_seconds() for i in range(len(dates) - 1)]

    # Compute average time difference in seconds
    avg_delta = sum(deltas) / len(deltas)

    # Convert to a timedelta object and then to a string in HH:MM:SS format
    avg_delta = str(datetime.utcfromtimestamp(avg_delta).time())

    return avg_delta


def predict_age_brackets(account_data, male_percentage, views_to_sub_ratio):
    """
    Predicts the age bracket percentages using saved Random Forest models.

    :param account_data: A dictionary with years as keys and number of accounts created as values.
    :param male_percentage: Value for 'male percentage prediction'.
    :param views_to_sub_ratio: Value for 'views to sub ratio'.
    :return: A dictionary with predicted percentages for each age bracket.
    """

    model_paths = {
        '% 0 - 17': './rf_models/rf_model__0-17.joblib',
        '% 18-24': './rf_models/rf_model__18-24.joblib',
        '% 25-34': './rf_models/rf_model__25-34.joblib',
        '% 35-44': './rf_models/rf_model__35-44.joblib',
        '% 45+': './rf_models/rf_model__45+.joblib'
    }

    # Prepare input data for prediction
    input_data = [account_data.get(str(year), 0) for year in range(2006, 2025)]
    input_data.extend([male_percentage, views_to_sub_ratio])

    # Initialize predictions
    predictions = {}
    total_percentage = 0

    # Predict using the Random Forest models
    for age_bracket, model_path in model_paths.items():
        # Load the model
        model = joblib.load(model_path)
        # Make prediction
        prediction = model.predict([input_data])[0]
        # Apply minimum threshold of 1%
        adjusted_prediction = max(0.01, prediction)
        predictions[age_bracket] = adjusted_prediction
        total_percentage += adjusted_prediction

    # Now, scale all predictions to make sure they sum up to 100%
    for age_bracket in predictions:
        predictions[age_bracket] = (predictions[age_bracket] / total_percentage) * 100

    return predictions


from google.cloud import bigquery
from google.oauth2 import service_account


class bigqueryConnection(object):

    def __init__(self):
        credentials = service_account.Credentials.from_service_account_file(
            'service_account/service_account.json')
        project_id = 'growthunders'
        self.client = bigquery.Client(credentials=credentials, project=project_id)

    def bq_query(self, query):
        query_job = self.client.query(query)
        results = query_job.result()
        return results

    def create_temp_table(self, table_id):
        temp_table_id = f"{table_id}_temp"
        schema = self.client.get_table(table_id).schema
        temp_table = bigquery.Table(temp_table_id, schema=schema)
        self.client.create_table(temp_table)
        print(f"Temporary table {temp_table_id} created.")

    def insert_data(self, table_id, rows_to_insert):
        temp_table_id = f"{table_id}"
        errors = self.client.insert_rows_json(temp_table_id, rows_to_insert)
        if errors == []:
            print("New rows have been added to the table.")
        else:
            print(f"Encountered errors while inserting rows: {errors}")

    def merge_tables(self, table_id):
        temp_table_id = f"{table_id}_temp"
        merge_query = f"""
            MERGE {table_id} T
            USING {temp_table_id} S
            ON T.channel_id = S.channel_id
            WHEN NOT MATCHED THEN
                INSERT ROW
        """
        self.bq_query(merge_query)
        print("Data from the temporary table has been merged with the main table.")

    def delete_temp_table(self, table_id):
        temp_table_id = f"{table_id}_temp"
        self.client.delete_table(temp_table_id)
        print(f"Temporary table {temp_table_id} has been deleted.")

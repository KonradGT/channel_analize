from ratelimit import limits, sleep_and_retry
import requests
import random

# Define constants for rate limiting
CALLS_PER_SECOND = 30  # Adjust as per YouTube's allowed rate limit

@sleep_and_retry
@limits(calls=CALLS_PER_SECOND, period=1)
def call_youtube_request(url):

    cookie_string = "YSC=F8oTIByqSPg; VISITOR_PRIVACY_METADATA=CgJQTBICEgA%3D; CONSENT=PENDING+041; PREF=tz=Europe.Warsaw; __Secure-YEC=CgtIRjJ6RkJMUkVuWSiBsIypBjIICgJQTBICEgA%3D; SOCS=CAESEwgDEgk1NzA4NTUzMzIaAmVuIAEaBgiA4oepBg"
    cookies = {cookie.split('=')[0]: cookie.split('=')[1] for cookie in cookie_string.split('; ')}
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0'
    }

    response = requests.get(url, cookies=cookies, headers=headers)
    http_string = response.text

    return http_string